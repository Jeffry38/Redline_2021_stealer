﻿using System;

// Token: 0x02000042 RID: 66
public struct TableEntry
{
	// Token: 0x04000043 RID: 67
	public string[] Content;
}
