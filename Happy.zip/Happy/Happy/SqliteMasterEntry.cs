﻿using System;

// Token: 0x02000041 RID: 65
public struct SqliteMasterEntry
{
	// Token: 0x04000040 RID: 64
	public string ItemName;

	// Token: 0x04000041 RID: 65
	public long RootNum;

	// Token: 0x04000042 RID: 66
	public string SqlStatement;
}
