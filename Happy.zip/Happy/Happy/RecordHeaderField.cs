﻿using System;

// Token: 0x02000040 RID: 64
public struct RecordHeaderField
{
	// Token: 0x0400003E RID: 62
	public long Size;

	// Token: 0x0400003F RID: 63
	public long Type;
}
