﻿using System;

// Token: 0x02000055 RID: 85
public class GeoInfo
{
	// Token: 0x17000060 RID: 96
	// (get) Token: 0x060001D0 RID: 464 RVA: 0x0000A0A4 File Offset: 0x000082A4
	// (set) Token: 0x060001D1 RID: 465 RVA: 0x0000A0AC File Offset: 0x000082AC
	public string IP { get; set; }

	// Token: 0x17000061 RID: 97
	// (get) Token: 0x060001D2 RID: 466 RVA: 0x0000A0B5 File Offset: 0x000082B5
	// (set) Token: 0x060001D3 RID: 467 RVA: 0x0000A0BD File Offset: 0x000082BD
	public string Location { get; set; }

	// Token: 0x17000062 RID: 98
	// (get) Token: 0x060001D4 RID: 468 RVA: 0x0000A0C6 File Offset: 0x000082C6
	// (set) Token: 0x060001D5 RID: 469 RVA: 0x0000A0CE File Offset: 0x000082CE
	public string Country { get; set; }

	// Token: 0x17000063 RID: 99
	// (get) Token: 0x060001D6 RID: 470 RVA: 0x0000A0D7 File Offset: 0x000082D7
	// (set) Token: 0x060001D7 RID: 471 RVA: 0x0000A0DF File Offset: 0x000082DF
	public string PostalCode { get; set; }
}
