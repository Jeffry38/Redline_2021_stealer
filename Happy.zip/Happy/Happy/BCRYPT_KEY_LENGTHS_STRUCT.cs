﻿using System;

// Token: 0x02000049 RID: 73
public struct BCRYPT_KEY_LENGTHS_STRUCT
{
	// Token: 0x04000068 RID: 104
	public int dwMinLength;

	// Token: 0x04000069 RID: 105
	public int dwMaxLength;

	// Token: 0x0400006A RID: 106
	public int dwIncrement;
}
